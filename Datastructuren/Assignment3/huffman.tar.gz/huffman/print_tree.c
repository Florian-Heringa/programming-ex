#include <stdio.h>
#include "huffman.h"

void print_tree(tree_t root) {
    // ... SOME CODE MISSING HERE ...
}
