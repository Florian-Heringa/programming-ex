#include "huffman.h"

int print_code(code c) {

    // ... SOME CODE MISSING HERE ...

    return 0;
}

