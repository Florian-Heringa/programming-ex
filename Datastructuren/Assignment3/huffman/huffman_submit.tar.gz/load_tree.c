#include "huffman.h"
#include "stack.h"

tree_t load_tree(char *input) {

    // ... SOME CODE MISSING HERE ...

    return 0;
}
