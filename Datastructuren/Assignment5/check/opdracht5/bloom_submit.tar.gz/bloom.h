#include <stddef.h>

// Initialises a bloom_fitler struct
struct bloom *init_bloom(size_t n, size_t k, void *ks[k]);
// Frees bloom filter struct
void free_bloom(struct bloom filter);
// Adds a word to the filter through use of defined hashes
void bloom_add(struct bloom *filter, const size_t len, const char *value);
// Checks if a word is definitely not in, or maybe in the filter
int bloom_check(struct bloom *filter, const size_t len, const char *value);