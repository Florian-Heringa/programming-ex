#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "bitvec.h"

#define INT_SIZE 32

struct vec {
	size_t size;
    int32_t *vec_ar;
};

struct vec *bitvec_alloc(size_t n) {

    struct vec *v = malloc(sizeof(struct vec));
    if (!v) {
    	return NULL;
    }

    v->vec_ar = malloc(sizeof(int32_t) * ((n/INT_SIZE) + 1));

    if (!v->vec_ar) {	
    	free(v);
    	return NULL;
    }

    v->size = n;

    for (size_t i = 0; i < (n/INT_SIZE) + 1; i++) {

    	v->vec_ar[i] = 0;
    }

    return v;
}

void bitvec_free(struct vec *vec)
{
    free(vec->vec_ar);
    free(vec);
}

int bitvec_get(struct vec *vec, size_t i, bit *val) {

	if (i > vec->size) {
		return ARRAY_OUT_OF_BOUNDS;
	}

    int index = i / INT_SIZE;
    int get_bit = i % INT_SIZE;
    int32_t mask = 1 << get_bit;

    // printf("Index: %d, get_bit: %d, mask: %d\n", index, get_bit, mask);

    *val = (vec->vec_ar[index] & mask) >> get_bit;

    return ARRAY_OK;
}

int bitvec_set(struct vec *vec, size_t i, bit v) {

	if (i > vec->size) {
		return ARRAY_OUT_OF_BOUNDS;
	}

    int index = i / INT_SIZE;
    int set_bit = i % INT_SIZE;
    int32_t mask = 1 << set_bit;

    if (v == 1) {
    	vec->vec_ar[index] |= mask;
    } else if (v == 0) {
        vec->vec_ar[index] &= ~(mask);
    } else {
    	return ARRAY_ILLEGAL_VARIABLE;
    }

    // printf("Index: %d, set_bit: %d, mask: %d\n", index, set_bit, mask);

    return ARRAY_OK;
}
