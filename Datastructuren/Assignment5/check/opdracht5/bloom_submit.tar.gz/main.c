#include <stdio.h>
#include <stdlib.h>

#include "bitvec.h"
#include "hash.h"
#include "bloom.h"

#define BUF_SIZE 1024

static char buf[BUF_SIZE];

/*
 * Initialize the hashfunc arguments using the given `k` command line arguments
 * `kv_args`. It returns these arguments converted in a fresh void pointer
 * array.
 */
void **init_ks(size_t k, char *kv_args[k])
{
    void **ks;

    if (!(ks = calloc(k, sizeof(void *)))) {
        return NULL;
    }

    for (size_t i = 0; i < k; i++) {
        long *param = malloc(sizeof(long));
        if (!param) {
            for (size_t i = 0; i < k; i++) {
                free(ks[i]);
            }
            free(ks);
            return NULL;
        }
        /* Set your param here. */
        *param = atol(kv_args[i]);
        ks[i] = param;
    }
    return ks;
}

void test() {

    struct vec *v = bitvec_alloc(29);
    bit b = 0;

    bitvec_set(v, 10, 0);

    printf("%d\n", b);
    bitvec_get(v, 9, &b);
    printf("%d\n", b);
    bitvec_get(v, 10, &b);
    printf("%d\n", b);

    bitvec_free(v);
}

int main(int argc, char *argv[])
{

    //test();

    //exit(1);
    void **ks = NULL;
    size_t k, n;

    if (argc < 3 || (k = atol(argv[1])) < 1 || (argc - atoi(argv[1])) != 3) {
        printf("usage: %s <k> <n> <ks>\n", argv[0]);
        return 1;
    }

    n = atol(argv[2]);

    if (!(ks = init_ks(k, argv + 3))) {
        return EXIT_FAILURE;
    }

    /* GLORY AND HACKS AWAIT! */
    struct bloom *bloom_filter = init_bloom(n, k, ks);

    size_t read = 0;
    size_t printed = 0;
    int not_in_filter;
    size_t len = 0;

    while (1) {
        char *s = fgets(buf, BUF_SIZE, stdin);
        char *a = s;
        while (a++) {
            len++;
        }

        if (s == NULL) {
            fprintf(stderr, "Unexpected end of file. Exiting\n");
            exit(1);
        }

        // TODO: add bloom filter functionality, first check if word is definitely in
        // if not add and print, if it is, continue.
        not_in_filter = bloom_check(bloom_filter, len, s);

        if (not_in_filter) {
            printf("%s\n", s);
            printed++;
        }

        len = 0;
        read++;
    }

    for (size_t i = 0; i < k; i++) {
        printf("%ld\n", *(long*)ks[i]);
        free(ks[i]);
    }
    free(ks);
    return EXIT_SUCCESS;
}
