#include "bitvec.h"

struct vec {
    /* GLORY AND HACKS AWAIT! */
};

struct vec *bitvec_alloc(size_t n)
{
    /* GLORY AND HACKS AWAIT! */
    return NULL;
}

void bitvec_free(struct vec *vec)
{
    /* GLORY AND HACKS AWAIT! */
}

int bitvec_get(struct vec *vec, size_t i, bit *val)
{
    /* GLORY AND HACKS AWAIT! */
    return 0;
}

int bitvec_set(struct vec *vec, size_t i, bit v)
{
    /* GLORY AND HACKS AWAIT! */
    return 0;
}
