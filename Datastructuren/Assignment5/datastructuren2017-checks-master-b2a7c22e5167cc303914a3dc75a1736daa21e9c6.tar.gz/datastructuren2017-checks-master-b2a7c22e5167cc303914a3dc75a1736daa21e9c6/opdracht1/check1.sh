#!/usr/bin/env bash


make clean;

fail() { echo $1; exit 1; }


declare -r COLORS_SUPPORTED=$(bc <<< "`(tput colors) 2>/dev/null || echo 0` >= 8")
#
# src="mm.c `grep ^ADDITIONAL_SOURCES Makefile | cut -d = -f 2`"
# hdr=`grep ^ADDITIONAL_HEADERS Makefile | cut -d = -f 2`

# cd to one dir above check script
#XXX: cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/.."

bail() {
    printf "$1\n\n"
    echo "preliminary grade: $grade"
    rm -f _out
    exit 1
}

summary_field() {
    if [ $ret -eq 0 ]
    then grep "$*" _out | sed 's/[^:]\+: //'
    else echo undefined
    fi
}

grade=0
grant() {
    echo -n "grade "
    [ `bc <<< "$1 > 0"` -eq 1 ] && printf +
    echo $1
    grade=`bc <<< "$grade + $1" | sed 's/^\./0./'`
}

header() { printf "%-70s" "$*"; }
color() {
    if [ $COLORS_SUPPORTED -eq 1 ]
    then echo -e "\033[1;${1}m${*:2}\033[0m"
    else echo ${*:2}
    fi
}
ok()   { echo [ `color 32 ok` ]; }
fail() { echo [ `color 31 failed` ]; }

check_fail() {
    local ret=$?
    if [ $ret -ne 0 ]
    then
        fail
        [ "$cmd" ] && echo "command: $cmd"
        [ "$OUT" ] && printf "$OUT\n"
    fi
    return $ret
}
check() {
    check_fail
    ret=$?
    [ $ret -eq 0 ] && ok
    return $ret
}
invert() { [ $? -ne 0 ]; }


# +0.5pt for submitted AUTHORS file and non-empty report.pdf
header "checking AUTHORS"

[ -e AUTHORS ]
check_fail || bail "AUTHORS does not exist"
AUTHORS=`python parse_authors.py < AUTHORS`
check_fail || bail "AUTHORS format invalid: \n$AUTHORS"

grant 0.5

# +0.5pt if code compiles without errors and mm.c is modified in any way
header "checking infix2rpn.c and stack.c for modifications"
cmd="diff infix2rpn.c infix2rpn-empty.c"
diff -q infix2rpn.c infix2rpn-empty.c && diff -q  >/dev/null
invert; check || bail "infix2rpn.c has not been modified"
diff -q stack.c stack-empty.c && diff -q  >/dev/null
invert; check || bail "stack.c has not been modified"

header "compiling"
cmd="make"
#XXX: if make_err=`make clean all 2>&1 >/dev/null`; check
if make_err=`make 2>&1 >/dev/null`; check
then grant 0.5
else bail "$make_err\ncompilation failed, quitting"
fi
echo

header "checking stack implemenation"

cmd="./stack-test"
./stack-test 2>&1|grep "FAILED"
invert;
if check;
then grant 1.0
else echo "push / pull failed"
fi

header "checking stats"
cmd="./stack-test"
./stack-test 2>&1|grep "stats" |diff - expectedStats.txt
if check;
then grant 1.0
else "stack stats wrong"
fi


exprs_stuff=('3 + 5 * 10' '100 * 10 / 20')


exprs=('3 + 4 * 2 / ( 1 - 5 ) ^ 2 ^ 3' \
    '( ( 1 + 2 ) ^ ( 3 + 4 ) ) ^ ( 5 + 6 )')

exprs_power=('2^3^4' '2^3')

exprs_power_ref=('2 3 ^ 4 ^' '2 3 ^')

simple_exprs=('3+3' '3+4*5' '3*8' '3+3+3+3+3+3+3+3+3+3' '3/8')

exprs_space=('13 +   4 *             2 / ( 1 - 5 ) ^ 2 ^ 3')
exprs_space_second=('2 2 + 2')
exprs_space_second_ref=('22 2 +')

xfail_exprs=('((1 + 2)' ' ((1 * 2) + 3' '(1*2))' '(1*2) + 3)' \
    ')(' ' 1 + )( 1' '1 + 1 )(')


require_parser=('()' '1 1' '1 1 +' '1 + 1 +' '1 +' '+ 1')

no_f_eval=('3 ^ (4+2)f' '(2)g' '(((2)g)f)h' '(2)g ^ (3)f')

ref_f_noeval=('3 4 2 + f ^' '2 g' '2 g f h' '2 g 3 f ^')

no_til_eval=('~2^3' '~~2')

ref_til_noeval=('2 ~ 3 ^' '2 ~ ~')

PROG=./infix2rpn
header "checking simple expressions"

for e in "${simple_exprs[@]}"
do
    echo "$e"
    infix_res=`echo "$e" | bc`
    rpn_expr=`$PROG "$e" 2>/dev/null`
    echo "$rpn_expr"
    rpn_res=`echo "$rpn_expr p" | dc`
    if (( $infix_res == $rpn_res ))
    then
        echo "OK"
		grant 0.20
    else
        echo "FAILED"
        echo "infix result: $infix_res"
        echo "rpn result:   $rpn_res"
    fi
    echo
done

header "checking precedence levels"

for e in "${exprs_stuff[@]}"
do
    echo "checking: $e"
    infix_res=`echo "$e" | bc`
    rpn_expr=`$PROG "$e" 2> /dev/null`
    echo "$rpn_expr"
    rpn_res=`echo "$rpn_expr p" | dc`
    if (( $infix_res == $rpn_res ))
    then
        echo "OK"
		grant 0.5
    else
        echo "FAILED"
        echo "infix result: $infix_res"
        echo "rpn result:   $rpn_res"
    fi
    echo
done

header "checking complex equations"

for e in "${exprs[@]}"
do
    echo "checking: $e"
    infix_res=`echo "$e" | bc`
    rpn_expr=`$PROG "$e" 2> /dev/null`
    # echo "$rpn_expr"
    rpn_res=`echo "$rpn_expr p" | dc`
   if (( $infix_res == $rpn_res ))
   then
        echo "OK"
	grant 0.5
    else
        echo "FAILED"
        echo "infix result: $infix_res"
        echo "rpn result:   $rpn_res"
    fi
    echo
done

# -1pt if $(CC) -W -Wall reports warnings
header "checking if compilation with CFLAGS=-W -Wall reports warnings"
if [ "$make_err" ]
then fail; echo "$make_err"; grant -1
else ok
fi
echo

header "checking if valgrind reports errors"
out=`valgrind ./stack-test 2>&1`
OUT="$out" check || grant -1
echo

# -1pt if your source files are not neatly indented.
header "assuming errors are handled correctly"
ok
grant 0.5
echo

if [ `bc <<< "$grade < 5"` -eq 1 ]
then bail "did not get at least 5 points, quitting"
fi

header "checking spaces levels"

for e in "${exprs_space[@]}"
do
    echo "checking: $e"
    infix_res=`echo "$e" | bc`
    rpn_expr=`$PROG "$e" 2> /dev/null`
    # echo "$rpn_expr"
    rpn_res=`echo "$rpn_expr p" | dc`
    if (( $infix_res == $rpn_res ))
    then
        echo "OK"
		grant 0.5
    else
        echo "FAILED"
        echo "infix result: $infix_res"
        echo "rpn result:   $rpn_res"
    fi
    echo
done

header "checking spaces hard"
count=0
for e in "${exprs_space_second[@]}"
do
    echo "$e"
    # ignore whitespace here.
    rpn_expr=`$PROG "$e" 2> /dev/null | sed -e 's/\s\+/ /g' | sed -e 's/^\s\+//g' `
    echo "$rpn_expr"
    if [ "$rpn_expr" == "${exprs_space_second_ref[count]}" ]
    then
        echo "OK"
		grant 0.5
    else
        echo "FAILED"
        echo "infix input: $e"
        echo "rpn result:   $rpn_expr"
        echo "ref result:   ${exprs_space_second_ref[count]}"
    fi
    echo
    count=$(( $count + 1 ))
done



echo "Functions"
count=0
for e in "${no_f_eval[@]}"
do
    echo "$e"
    # ignore whitespace here.
    rpn_expr=`$PROG "$e" 2> /dev/null | sed -e 's/\s\+/ /g' | sed -e 's/^\s\+//g' `
    echo "$rpn_expr"
    if [ "$rpn_expr" == "${ref_f_noeval[count]}" ]
    then
        echo "OK"
		grant 0.125
    else
        echo "FAILED"
        echo "infix input: $e"
        echo "rpn result:   $rpn_expr"
        echo "ref result:   ${ref_f_noeval[count]}"
    fi
    echo
    count=$(( $count + 1 ))
done

echo "tilde operator"
count=0
for e in "${no_til_eval[@]}"
do
    echo "$e"
    # ignore whitespace here.
    rpn_expr=`$PROG "$e" 2> /dev/null | sed -e 's/\s\+/ /g' | sed -e 's/^\s\+//g' `
    echo "$rpn_expr"
    if [ "$rpn_expr" == "${ref_til_noeval[count]}" ]
    then
        echo "OK"
		grant 0.5
    else
        echo "FAILED"
        echo "infix input: $e"
        echo "rpn result:   $rpn_expr"
        echo "ref result:   ${ref_til_noeval[count]}"
    fi
    echo
    count=$(( $count + 1 ))
done

count=0
header "checking power equations"

for e in "${exprs_power[@]}"
do
    echo "$e"
    # ignore whitespace here.
    rpn_expr=`$PROG "$e" 2> /dev/null | sed -e 's/\s\+/ /g' | sed -e 's/^\s\+//g' `
    echo "$rpn_expr"
    if [ "$rpn_expr" == "${exprs_power_ref[count]}" ]
    then
        echo "OK"
		grant 0.5
    else
        echo "FAILED"
        echo "infix input: $e"
        echo "rpn result:   $rpn_expr"
        echo "ref result:   ${exprs_power_ref[count]}"
    fi
    echo
    count=$(( $count + 1 ))
done



# report grade
echo "preliminary grade: $grade"

# cleanup
rm -f _out

