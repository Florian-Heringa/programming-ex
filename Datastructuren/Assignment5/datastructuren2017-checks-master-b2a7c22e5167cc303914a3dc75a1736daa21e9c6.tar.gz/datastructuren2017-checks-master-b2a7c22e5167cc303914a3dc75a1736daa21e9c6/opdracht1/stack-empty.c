#include <stdlib.h>

#include "stack.h"

#define STACK_SIZE 100

struct stack {
    // ... SOME CODE MISSING HERE ...
};

struct stack *stack_init() {
    struct stack* s = malloc(sizeof(struct stack));

    // ... SOME CODE MISSING HERE ...

    return s;
}

void stack_cleanup(struct stack* s) {

    // ... SOME CODE MISSING HERE ...

}

// ... SOME CODE MISSING HERE ...
