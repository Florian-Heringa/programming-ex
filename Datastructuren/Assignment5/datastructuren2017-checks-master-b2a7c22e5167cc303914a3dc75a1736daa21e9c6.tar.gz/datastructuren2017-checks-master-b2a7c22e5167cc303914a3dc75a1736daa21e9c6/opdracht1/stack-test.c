#include <stdio.h>

#include "stack.h"

int error_count;

void start_test(char *msg) {
    printf("\nTEST: %s\n", msg);
    error_count = 0;
}

void end_test() {
    if (error_count > 0) {
        printf("FAILED: %d errors\n", error_count);
    } else {
        printf("PASSED\n");
    }
}

int expect(int got, int expect) {
    if (expect != got) {
        printf("Expected %d, got %d\n", expect, got);
        error_count++;
    }
    return got;
}

int safe_push(struct stack* s, char c) {
    int r;
    if ((r = stack_push(s, c)) != 0) {
        printf("stack_push unexpected return value: %d\n", r);
        error_count++;
    }
    return r;
}

int check_pop(struct stack* s, char expect) {
    char got;
    if (expect != (got = stack_pop(s))) {
        printf("stack_pop unexpected return value: %c\n", got);
        error_count++;
        return 1;
    }
    return 0;
}

/* Tests for the character stack data structure.  */
int main() {
    int r;
    struct stack* s1;
    struct stack* s2;

    start_test("stack init/cleanup");
    s1 = stack_init();
    if (!s1)
        printf("error in init\n");
    stack_cleanup(s1);
    end_test();

    start_test("stack_empty");
    s1 = stack_init();
    expect(stack_empty(s1), 1);
    safe_push(s1, 'x');
    expect(stack_empty(s1), 0);
    stack_cleanup(s1);
    end_test();

    start_test("push/peek/pop");
    s1 = stack_init();
    safe_push(s1, 'a');
    safe_push(s1, 'b');
    safe_push(s1, 'c');
    expect(stack_peek(s1), 'c');
    check_pop(s1, 'c');
    expect(stack_peek(s1), 'b');
    check_pop(s1, 'b');
    stack_cleanup(s1);
    end_test();

    start_test("pop on empty stack");
    s1 = stack_init();
    check_pop(s1, -1);
    stack_cleanup(s1);
    end_test();

    start_test("stack full behaviour");
    s1 = stack_init();
    for (int i = 0; i < 100000; i++) {
        r = stack_push(s1, 'a');
        if ( !((r == 0) || (r == 1)) ) {
            printf("unexpected return value from push: %d\n", r);
            break;
        }
    }
    for (int i = 0; i < 100000; i++) {
        r = stack_pop(s1);
        if ( !((r == 'a') || (r == -1)) ) {
            printf("unexpected return value from pop: %d\n", r);
            break;
        }
    }
    stack_cleanup(s1);
    end_test();

    start_test("using multiple stacks");
    s1 = stack_init();
    s2 = stack_init();
    safe_push(s1, 'A');
    safe_push(s1, 'B');
    safe_push(s1, 'C');
    safe_push(s2, stack_pop(s1));
    safe_push(s2, stack_pop(s1));
    safe_push(s2, stack_pop(s1));
    check_pop(s2, 'A');
    check_pop(s2, 'B');
    check_pop(s2, 'C');
    stack_cleanup(s1);
    stack_cleanup(s2);
    end_test();

    return 0;
}
