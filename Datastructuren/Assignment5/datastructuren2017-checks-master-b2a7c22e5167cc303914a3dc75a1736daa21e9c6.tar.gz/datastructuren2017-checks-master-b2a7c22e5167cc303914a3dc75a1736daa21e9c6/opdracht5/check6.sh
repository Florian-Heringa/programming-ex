#!/bin/bash

declare -r COLORS_SUPPORTED=1
export LIBC_FATAL_STDERR_=2
export _GRADE=0 # The current grade
export _VALGRIND_FILE="$(mktemp)"
export _VALGRIND_OK=0 # Have we seen a valgrind error
export _VALGRIND_POINTS=1 # points to add if no valgrind errors were found.
export _TIMEOUT_TIME=1 # The max time a command may run
export LC_NUMERIC="en_US.UTF-8"

cd "$(dirname "$0")"

_errcho() {
    (>&2 echo "$@")
}

exit_trap() {
    rm "$_VALGRIND_FILE"
}

trap exit_trap EXIT

# Grant the given number of points. The number should be the first and only argument.
grant() {
    ok
    printf ", you got %+.1f points\n" "$1"
    _GRADE=`bc -l <<< "scale=1;$_GRADE + $1"`
}

not_grant() {
    fail
    printf ", you missed %0.1f points\n" "$1"
}

bail() {
    printf "\nBailing: %s\n\n" "$*"
    printf "preliminary grade: %0.1f\n" "$_GRADE"
    exit 1
}

header() {
    printf "%-70s" "$*"
}

color() {
    if [[ $COLORS_SUPPORTED -eq 1 ]]; then
        printf "\033[1;%sm%s\033[0m" "$1" "${*:2}"
    else
        shift
        printf "%s" "$*"
    fi
}

ok() {
    color 32 "PASS"
}

fail() {
    color 31 "FAIL"
}

with_timeout () {
    timeout -k "$_TIMEOUT_TIME" "$_TIMEOUT_TIME" "$@"
}

# Grant the given amount of points after running the specified command.
#
# The points to grant should be specified in the first argument, the command to
# run in the rest arguments (no splitting is done). The command is not eval'd so
# you can only pass things that you can pass behind timeout.
#
# If the test is successful this is shown to the user and the amount of points
# is also shown. If the tests failed the output is shown including the amount of
# points missed. The return value of this function is the same as of the test
# command.
check_success() {
    local extra="$1" outfile="$(mktemp)" ret
    shift
    with_timeout "$@" > "$outfile" 2>&1
    ret="$?"
    if [[ "$ret" -eq 0 ]]; then
        [[ "$extra" != "0" ]] && grant "$extra"
    else
        not_grant "$extra"
        echo 'Error output:'
        cat "$outfile"
        echo
    fi
    rm "$outfile"
    return "$ret"
}

# Exactly the same as `check_success()` only this function will bail on a
# unsuccessful test. The first argument should contain the bail message.
check_bail() {
    local msg="$1" ret
    shift
    check_success "$@"
    ret="$?"
    if [[ "$ret" -ne 0 ]]; then
        bail "$msg"
    fi
    return "$ret"
}

# Grant the given amount of points after running the specified command and
# comparing its output to the reference output.
#
# The points to grant should be specified in the first argument, the file to
# diff with as the second argument and the command to run in the rest arguments.
# The command is not eval'd so you can only pass things that you can pass behind
# timeout.
#
# If the test is successful this is shown to the user and the amount of points
# is also shown. If the tests failed the output is shown including the amount of
# points missed. For a successful test the command should return 0 and its
# output should be equal to the reference output.
#
# The return value of this function is the same as of the test command.
check_equal() {
    local extra="$1" todiff="$2" diffout="$(mktemp)" outfile="$(mktemp)" ret
    shift; shift
    with_timeout "$@" > "$outfile" 2>&1
    ret="$?"

    if [[ "$ret" -eq 0 ]]; then
        diff -y "$outfile" "$todiff" > "$diffout"
        ret="$?"
        if [[ "$ret" -eq 0 ]]; then
            grant "$extra"
        else
            not_grant "$extra"
            echo "Differences (left is your output, right is the reference):"
            cat "$diffout"
            echo
        fi
    elif [[ "$ret" -gt 100 ]]; then
        not_grant "$extra"
        echo "There was a timeout. Output:"
        cat "$outfile"
        echo
    else
        echo
        not_grant "$extra"
        echo "You're command exit with an error code, not diffing. Output:"
        cat "$outfile"
        echo
    fi

    rm "$outfile"
    rm "$diffout"
    return "$ret"
}

# Exactly the same as `check_equal` only checking for not equal.
check_notequal() {
    local extra="$1" todiff="$2" diffout="$(mktemp)" outfile="$(mktemp)" ret
    shift; shift
    with_timeout "$@" > "$outfile" 2>&1
    ret="$?"

    if [[ "$ret" -eq 0 ]]; then
        ! diff -y "$outfile" "$todiff" > "$diffout"
        ret="$?"
        if [[ "$ret" -eq 0 ]]; then
            ok; echo
        else
            fail; echo
        fi
    elif [[ "$ret" -gt 100 ]]; then
        fail; echo
        echo "There was a timeout. Output:"
        cat "$outfile"
        echo
    else
        fail; echo
        echo "You're command exit with an error code, not diffing. Output:"
        cat "$outfile"
        echo
    fi

    rm "$outfile"
    rm "$diffout"
    return "$ret"
}

# Check the given command with valgrind. This will check if the command resulted
# in valgrind errors. This will not output any thing! Use `finalize_valgrind()` to
# do this. There is no useful return code. You can only provide things as a
# command that are suitable for usage after valgrind.
check_valgrind() {
    local ret
    with_timeout valgrind --error-exitcode=127 "$@" >> "$_VALGRIND_FILE" 2>&1
    ret="$?"
    if [[ "$ret" -gt 100 ]]; then
        _VALGRIND_OK=1
    fi
    return 0
}

# Finalize the valgrind tests. The return code is 0 if no valgrind test failed
# and 1 otherwise.
finalize_valgrind() {
    local ret
    if [[ "$_VALGRIND_OK" -eq 0 ]]; then
        grant "$_VALGRIND_POINTS"
        ret=0
    else
        not_grant "$_VALGRIND_POINTS"
        cat "$_VALGRIND_FILE"
        ret=1
    fi
    rm "$_VALGRIND_FILE"
    _VALGRIND_FILE="$(mktemp)"
    return "$ret"
}


## ALL TESTS START HERE


# Start clean
make clean

header "checking AUTHORS"
check_bail "AUTHORS does not exist" 0 test -e AUTHORS
check_bail "AUTHORS format invalid: \n$AUTHORS" 0.5 python parse_authors.py < AUTHORS

header "checking hash.c for modifications"
if ! check_notequal 0 "hash-empty.c" cat "hash.c"; then
    bail "hash.c has not been modified"
fi

header "checking bitvec.c for modifications"
if ! check_notequal 0 "bitvec-empty.c" cat "bitvec.c"; then
    bail "bitvec.c has not been modified"
fi

header "checking main.c for modifications"
if ! check_notequal 0 "main-empty.c" cat "main.c"; then
    bail "main.c has not been modified"
fi

header "Compiling without -Werror"
check_bail "Compilation failed." 0.5 make all

header "checking if compilation with CFLAGS=-W -Wall reports warnings"
check_success 0.5 make all_error

make all > /dev/null 2>&2

header "Running bitvec API tests"
check_success 1.0 ./bitvec-test

header "Running hash API tests"
check_success 2.0 false
echo ----------------------
echo " Not implemented yet"
echo ----------------------
echo

header "Running valgrind tests"
check_success -1.0 false
echo ----------------------
echo " Not implemented yet"
echo ----------------------
echo

header "Running Bloom filter tests (this will take a couple of minutes)"

flag=0
ratio=0
for f in tests/*.txt; do
    n=$(cat $f | sort -u | wc -l)
    for m in 5000 10000 20000 50000; do
        for k in {2..8}; do
            t=0
            for i in {0..9}; do 
                temp=$(mktemp)
                par=($(cat PARAMS | tr [:blank:] '\n' | shuf))
                ./dups $k $m ${par[@]:0:$k} < $f 1> $temp 2> /dev/null
                r=$(wc -l < $temp)
                if [ $r -eq 0 ] || [ $r -ne $(cat $temp | sort -u | wc -l) ]
                    then flag=1; echo 'Basic check failed' 
                fi
                t=`bc -l <<< "$t + $r/10"`
            done
            tmax=`bc -l <<< "r=0; for (i=0; i < $n; i++) r += 1 - (1 - e(-$k*i/$m))^$k; r;"`
            ratio=`bc -l <<< "$ratio + $t/$tmax"`
        done
    done
done

if [ $flag -eq 0 ]
then grant 2.0
else fail; echo ' Basic Bloom filter checks failed'
fi
echo

header "False positive tests"
score=`bc <<< "scale=1; $ratio*3/(4*4*7)"`
grant $score
echo

header "Running minimal representation bit vector tests"
check_success 1.0 false
echo ----------------------
echo " Not implemented yet"
echo ----------------------
echo


printf "Preliminary grade: %0.1f\n" "$_GRADE"
