#! /bin/bash

# Ask for name and print greeting to terminal
echo What is your name?
read -r input
echo Hello $input