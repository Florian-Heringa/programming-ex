interface BreukInterface {
    abstract Breuk telop(Breuk cg);
    abstract Breuk trekaf(Breuk cg);
    abstract Breuk vermenigvuldig(Breuk cg);
    abstract Breuk deel(Breuk cg);
    abstract Breuk omgekeerde();
}