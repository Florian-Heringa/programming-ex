interface BreukComplexGetalInterface {
    public BreukComplexGetal telop(BreukComplexGetal cg);
    public BreukComplexGetal trekaf(BreukComplexGetal cg);
    public BreukComplexGetal vermenigvuldig(BreukComplexGetal cg);
    public BreukComplexGetal deel(BreukComplexGetal cg);
    public BreukComplexGetal omgekeerde();
}