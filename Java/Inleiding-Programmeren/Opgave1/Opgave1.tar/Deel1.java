/* Florian Heringa
*  10385835
*  Prints "Florian" in ASCII art to the terminal
*/

public class Deel1 {
	public static void main(String[] args) {
		System.out.println("___________.__               .__               ");
		System.out.println
("\\_   _____/|  |   ___________|__|____    ____  ");
		System.out.println
(" |    __)  |  |  /  _ \\_  __ \\  \\__  \\  /    \\ ");
		System.out.println
(" |     \\   |  |_(  <_> )  | \\/  |/ __ \\|   |  \\");
		System.out.println
(" \\___  /   |____/\\____/|__|  |__(____  /___|  /");
		System.out.println
("     \\/                              \\/     \\/ ");	
	}
}
