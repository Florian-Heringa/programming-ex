
% queries for exercise 1
path(1,3,Path).
path(3,4,Path).
path(4,5,Path).

% queries for exercise 2
cost([edge(5, 4, 2)], Cost).
cost([edge(5, 1, 2), edge(1, 2, 5), edge(2, 4, 3)], Cost).

% queries for exercise 3



% queries for exercise 4